# Install

```
npm install
```

# Run

Starts a demo with the async library

```
npm start
```

Starts a demo on generators

```
npm run start:generator
```

Starts a demo with the async library and the parallell function

```
npm run start:parallell
```

Starts a demo with the async library and the async map function

```
start:async-map
```
