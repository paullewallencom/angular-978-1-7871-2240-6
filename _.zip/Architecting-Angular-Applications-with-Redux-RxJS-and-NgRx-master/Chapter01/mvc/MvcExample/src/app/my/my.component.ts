import { Component, OnInit } from "@angular/core";

@Component({
  selector: "my-component",
  template: ``
})
export class MyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
