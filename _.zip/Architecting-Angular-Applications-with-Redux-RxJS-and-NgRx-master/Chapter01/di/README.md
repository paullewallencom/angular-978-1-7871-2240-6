code is meant to be read through only, no DEMO available
