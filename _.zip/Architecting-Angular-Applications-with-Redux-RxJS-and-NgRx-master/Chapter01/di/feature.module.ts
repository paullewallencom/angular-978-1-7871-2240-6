import { Service } from "./Service";

@NgModule({
  providers : [ Service ]
})
export class FeatureModule{}