@NgModule({
    imports: [SharedModule],
    providers: [AppService]
})
export class AppModule { }