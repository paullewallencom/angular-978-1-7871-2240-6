export class Logger { }

export class ExampleService {
    constructor(logger: Logger) { }
}



