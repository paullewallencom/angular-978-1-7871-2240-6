@Component({
    selector: 'component'
})
export class ExampleComponent {
    constructor(srv: Service) { }
}