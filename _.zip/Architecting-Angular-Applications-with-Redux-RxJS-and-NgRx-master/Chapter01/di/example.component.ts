import { Service } from './service';

export class ExampleComponent {
    constructor(srv: Service) { }
}