@NgModule({
    providers: [SharedService]
})
export class SharedModule { } 