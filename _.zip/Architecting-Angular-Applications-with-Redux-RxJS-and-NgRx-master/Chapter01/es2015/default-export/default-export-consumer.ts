import Player from "./default-export";

const player = new Player();

player.attack();
player.move();
