export default class Player {
  attack() {
    console.log("attacking");
  }
  move() {
    console.log("moving");
  }
}

export const PI = 3.13;
