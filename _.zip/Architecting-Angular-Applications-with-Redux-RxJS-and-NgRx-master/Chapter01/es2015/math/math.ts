export class Math {
    add() { }
    subtract() { }
}

export const PI = 3.14; 