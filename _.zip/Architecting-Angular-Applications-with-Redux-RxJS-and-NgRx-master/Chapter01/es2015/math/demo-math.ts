import { Math, PI } from "./math";

const math = new Math();

console.log("running add() on Math");
math.add();

console.log("PI", PI);
