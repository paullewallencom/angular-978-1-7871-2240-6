The sub directory MarbleTesting is an Angular project

# Run & Install

Angular project that demoes the library jasmine marbles that lets you test Observables

```
cd MarbleTesting
npm install
npm run test
```
