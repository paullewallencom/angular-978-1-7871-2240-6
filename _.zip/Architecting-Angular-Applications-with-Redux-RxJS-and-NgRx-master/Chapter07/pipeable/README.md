# Install

```
npm install
```

# Run

Demoes how we can use pipeable operators. That is the same operators we have always used but this tree shakes properly

```
node pipeable.js
```
