import selectionView from './selectionView';
import selectedView from './selectedView';

selectionView.selectIndex(1);

