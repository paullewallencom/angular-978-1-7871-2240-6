# Install


Possibly also install http-server module if you don't have it:

```
npm install http-server -g
```

The below should install webpack, webpack-cli

```
npm install
```

# Run

```
npm start
```

