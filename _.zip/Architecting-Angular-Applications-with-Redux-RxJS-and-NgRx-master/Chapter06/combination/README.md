# Install

```
npm install
```

# Run

```
npm run start:merge
```

```
npm run start:concat
```

```
npm run start:combineLatest
```
