# Install

```
npm install
```

```
npm run start:from
```

```
npm run start:of
```

```
npm run start:range
```
