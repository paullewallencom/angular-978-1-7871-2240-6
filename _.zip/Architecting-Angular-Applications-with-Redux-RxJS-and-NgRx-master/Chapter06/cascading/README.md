its worth studying the difference between cascading-promises.js and cascading-rxjs.js

The former takes on the Promise approach whereas the latter uses RxJS.
