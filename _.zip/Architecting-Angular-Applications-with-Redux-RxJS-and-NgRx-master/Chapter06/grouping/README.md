# Install

if you are lacking http-server then run

```
npm install http-server -g
```

# Run

```
npm start
```

* open up a browser on localhost:5000
* right click inspect
* type into the input, wait a couple of seconds, see the logged out values
