# Install

```
npm install
```

# Run

```
npm run start:min
```

```
npm run start:max
```

```
npm run start:sum
```
