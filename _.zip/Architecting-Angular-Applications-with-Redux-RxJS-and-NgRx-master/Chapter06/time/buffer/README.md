# Install

```
npm install
```

# Run

```
npm start
```

* then start a browser on localhost:5000
* then right click and select inspect
* then type anything, wait two seconds, this should echo out all the buffered characters to the console
