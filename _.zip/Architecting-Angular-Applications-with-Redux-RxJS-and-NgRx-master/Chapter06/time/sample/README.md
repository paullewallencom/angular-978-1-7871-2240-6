# Run

```
npm start
```

* start a browser on localhost:5000
* riht click, choose inspect
* click on the button a few times.
  After 8 seconds it will output a click event.
  It will only output one value per 8 seconds.
