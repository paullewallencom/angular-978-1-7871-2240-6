# Install

```
npm install
```

# Run

```
npm start
```

- then start a browser on localhost:5000
- then right click and select inspect
- then type number in the input, e.g 1 or 11, wait two seconds, this should type fetched entry in the console

ex:
{ name: 'Anakin Skywalker'...}
