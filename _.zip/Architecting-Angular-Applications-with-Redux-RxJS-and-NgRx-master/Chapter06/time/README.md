# Install

```
npm install
```

# Run

```
npm run start:delay
```

```
npm run start:interval
```
