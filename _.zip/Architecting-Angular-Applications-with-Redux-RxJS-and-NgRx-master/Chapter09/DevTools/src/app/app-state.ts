export interface AppState {
  counter: number;
}
