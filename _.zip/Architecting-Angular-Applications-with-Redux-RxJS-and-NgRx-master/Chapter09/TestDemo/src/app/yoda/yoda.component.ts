import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yoda',
  templateUrl: './yoda.component.html',
  styleUrls: ['./yoda.component.css']
})
export class YodaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
