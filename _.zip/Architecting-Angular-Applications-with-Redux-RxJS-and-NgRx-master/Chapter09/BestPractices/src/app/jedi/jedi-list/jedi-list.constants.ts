export const ADD_JEDI = "ADD_JEDI";
export const REMOVE_JEDI = "REMOVE_JEDI";
export const LOAD_JEDIS = "LOAD_JEDIS";
