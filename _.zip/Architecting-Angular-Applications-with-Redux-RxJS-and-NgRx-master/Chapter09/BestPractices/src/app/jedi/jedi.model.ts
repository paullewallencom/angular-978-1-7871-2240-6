export interface Jedi {
  id: number;
  name: string;
}
