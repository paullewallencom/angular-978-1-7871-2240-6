export interface Counter {
  title: string;
  id: number;
}
