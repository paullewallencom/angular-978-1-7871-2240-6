import { CounterState } from "./counter/counter.module";

export interface AppState {
  counter: CounterState;
}
