General instructions

All of the subdirectories are Angular projects

cd into each directory and follow each auto generated README file which should say

```
npm install
ng serve
```
