# Run

Starts a demo that runs an imperative and declarative example on the same thing, finding the head in a linked list

```
npm start
```

Starts a demo calculating the amount of nodes in a tree

```
npm run start:count
```

Starts a demo calculating the depth in a tree

```
npm run start:depth
```

Starts a demo calculating the sum of the nodes in a tree

```
npm run start:sum
```

Starts a demo calculating the width in a tree

```
npm run start:width
```
