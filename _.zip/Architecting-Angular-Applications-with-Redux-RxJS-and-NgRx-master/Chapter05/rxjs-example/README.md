# Install

should install Rxjs

```
npm install
```

# Run

```
npm run start:producer
```

```
npm run start:subscription
```

```
npm run start:error
```

```
npm run start:completion
```
