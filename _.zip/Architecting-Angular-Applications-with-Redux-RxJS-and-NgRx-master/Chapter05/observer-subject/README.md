# Install

should install Rxjs and Typescript

```
npm install
```

# Run

```
npm start
```
