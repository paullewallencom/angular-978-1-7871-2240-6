export interface Observer {
  update();
}
