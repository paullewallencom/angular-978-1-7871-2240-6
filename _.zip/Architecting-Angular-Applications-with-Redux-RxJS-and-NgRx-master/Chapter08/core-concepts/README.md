# run

Running a reducer demo

```
npm run start:reducer
```

Running a list demo

```
npm run start:list
```
