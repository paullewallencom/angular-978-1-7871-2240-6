# Install

```
npm install
```

# Run

```
npm start
```

1 Open up a browser at localhost:5000

2 right click in the window, take inspect

3 input a value in the input field

4 verify that the value is written out in a list below the input field

The point of this demo is to use Redux for real in a scenario where we have:

* one control responsible for adding items to a list
* another control responsible for reading up a list from the store
