require('./reducer');
const BookView = require('./view');

module.exports = {
  BookView
};