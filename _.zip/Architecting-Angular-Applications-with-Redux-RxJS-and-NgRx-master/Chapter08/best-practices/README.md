# Run

```
npm run start
```
