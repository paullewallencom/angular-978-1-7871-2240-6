# install

```
npm install
```

# run

There are more than one demo. They are listed below

Runs a demo with a store

```
npm start
```

Runs a demo with a reducer

```
npm run start:first-reducer
```
